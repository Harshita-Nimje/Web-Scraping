const cheerio = require("cheerio");
const axios = require("axios");

const url = "https://books.toscrape.com/catalogue/category/books/mystery_3/index.html";

async function getScrape(){
    try {
        const response = await axios.get(url);
        const $=cheerio.load(response.data);
        const scrape = $("h1").text();

        console.log(scrape);
    }
    catch(error){
        console.error(error);
    }
}
getScrape();